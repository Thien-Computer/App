create table ass2.tuyenxe(
	id_tuyen varchar(4) primary key 
)
