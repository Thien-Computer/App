create table ass2.banggia(
	gia_xebus int not null,
    day_in_week int not null,
    day_last_week int not null,
    month_one  int not null
)	

