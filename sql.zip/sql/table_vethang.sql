create table ass2.vethang(
	id_ve varchar(16) primary key ,
     id_tuyen varchar(4) not null ,
     id_gatram1 varchar(7) not null,
     id_gatram2 varchar(7) not null,
      foreign key (id_ve) references ve(id_ve),
    foreign key (id_tuyen) references tuyenxe(id_tuyen),
    foreign key (id_gatram1) references ga_tram(id_gatram),
    foreign key (id_gatram2) references ga_tram(id_gatram),
    check (id_ve like 'VM%')
)
