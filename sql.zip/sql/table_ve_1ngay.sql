
drop table if exists ass2.ve_1ngay;
create table ass2.ve_1ngay(
	 id_ve varchar(16) primary key ,	
      used_at date not null,  
      foreign key (id_ve) references ve(id_ve),
      check(id_ve like 'VD%')
)
