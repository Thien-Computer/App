CREATE USER 'sManager'@'localhost' IDENTIFIED BY 'password';
GRANT ALL ON ass2.* TO 'sManager'@'localhost';